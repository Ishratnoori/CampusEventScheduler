from tkinter import Label, Tk, Frame, Button, Entry, messagebox
from mysql.connector import connect

conn = connect(
    host = 'localhost',
    user = 'root', #depends on your sql username
    password = '1234',
    database = 'demo'
)

cursor = conn.cursor()


font = ('Courier New', 20, 'bold italic')
class Home:
    def __init__(self, root) -> None:
        self.root = root
        self.main_frame = Frame(self.root, width= 550, height= 350)
        self.main_frame.place(x = 0, y = 0)
        self.name_lbl = Label(self.main_frame, text = "USER NAME", font = font, width= 10)
        self.name_lbl.place(x = 10, y = 50)
        self.name_entry = Entry(self.main_frame, font=font, width= 15)
        self.name_entry.place(x = 230, y = 50)
        
        self.pass_lbl = Label(self.main_frame, text='PASSWORD', font = font, width= 10)
        self.pass_lbl.place(x = 10, y = 150)
        self.pass_entry = Entry(self.main_frame, font= font, width= 15)
        self.pass_entry.place(x = 230, y = 150)

        self.login_btn = Button(self.main_frame, text= 'LOGIN', font = font, width= 10, command= self.login_fun)
        self.login_btn.place(x = 200, y = 240)

        self.goto_register = Label(self.main_frame, text= 'NOT A MEMBER YET? SIGNUP!', font=('Courier New', 10, 'bold'))
        self.goto_register.place(x = 5, y = 300)
        self.goto_register.bind("<Button-1>", self.change_page)

    def change_page(self,event):
        self.main_frame.destroy()
        register = Register(root)
    
    def login_fun(self):
        self.user_name = self.name_entry.get()
        self.user_pass = self.pass_entry.get()
        cursor.execute('select * from user_details;')
        self.data = cursor.fetchall()
        self.names = [name[0] for name in self.data]
        if self.user_name in self.names:
            cursor.execute(f"select roll from user_details where Name = '{self.user_name}'")
            self.pasw = cursor.fetchall()
            self.pasw = [passw[0] for passw in self.pasw]
            if self.user_pass in self.pasw:
                messagebox.showinfo('Login Succesfull',f'Welcome {self.user_name}')

             
   

class Register:
    def __init__(self, root) -> None:
        self.root = root
        self.main_frame = Frame(self.root, width= 550, height= 350, bg = 'steel blue')
        self.main_frame.place(x = 0, y = 0)
        self.name_lbl = Label(self.main_frame, text = "USER NAME", font = font, width= 10)
        self.name_lbl.place(x = 10, y = 50)
        self.name_entry = Entry(self.main_frame, font=font, width= 15)
        self.name_entry.place(x = 230, y = 50)
        
        self.pass_lbl = Label(self.main_frame, text='DEPARTMENT', font = font, width= 10)
        self.pass_lbl.place(x = 10, y = 100)
        self.pass_entry = Entry(self.main_frame, font= font, width= 15)
        self.pass_entry.place(x = 230, y = 100)

        self.roll_lbl = Label(self.main_frame, text='ROLL NO.', font = font, width= 10)
        self.roll_lbl.place(x = 10, y = 150)
        self.roll_entry = Entry(self.main_frame, font= font, width= 15)
        self.roll_entry.place(x = 230, y = 150)

        
        self.register_btn = Button(self.main_frame, text= 'REGISTER', font = font, width= 10, command= self.register_user)
        self.register_btn.place(x = 200, y = 240)

        self.goto_register = Label(self.main_frame, text= 'NOT A MEMBER YET? SIGNUP!', font=('Courier New', 10, 'bold'))
        self.goto_register.place(x = 5, y = 300)
        self.goto_register.bind("<Button-1>", self.change_page)

    def register_user(self):
        self.name  = self.name_entry.get()
        self.roll = self.roll_entry.get()
        self.dept = self.pass_entry.get() 
        self.query = "insert into user_details(Name, Dept, Roll) values(%s,%s,%s)"
        self.values = (self.name, self.dept,self.roll)
        cursor.execute(self.query, self.values)
        conn.commit()
        messagebox.showinfo('Account Created',f'UserName = "{self.name}"\nPassword = "{self.roll}"')
    def change_page(self,event):
        self.main_frame.destroy()
        home = Home(root)


root = Tk()
root.title('DEMO')
root.geometry('550x350+550+200')
root.resizable(False,False)
home = Home(root)
root.mainloop()