from mysql.connector import connect

conn = connect(
    host = 'localhost',
    user = 'root', #depends on your sql username
    password = '1234',
    database = 'demo'
)

cursor = conn.cursor()

'''query = 'insert into user_details(Name, Dept, Roll) values(%s,%s,%s)'
values = ('Deepika','IT-C','A2')
cursor.execute(query,values)
conn.commit()'''
cursor.execute('select * from user_details;')
data = cursor.fetchall()
print(data)

user = 'Apoorva'
names = [item[0] for item in data]
if user in names:
    print('yes')